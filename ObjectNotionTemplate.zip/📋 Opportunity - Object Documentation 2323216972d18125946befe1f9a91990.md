# 📋 Opportunity - Object Documentation

# Opportunity (Opportunity)

Represents a sales opportunity in the CRM system

## 📊 Object Summary

- 🔹 **Object Type:** Custom Object
- 🔹 **Deployment Status:** Deployed
- 🔹 **Sharing Model:** Read/Write
- 🔹 **External Object:** No
- 🔹 **Customizable:** Yes
- 🔹 **Queryable:** Yes
- 🔹 **Searchable:** Yes
- 🔹 **Triggerable:** Yes

## 📈 Component Statistics

- 🏷️ **Fields:** 156
- 📝 **Record Types:** 5
- 🔄 **Business Processes:** 4
- 📱 **Compact Layouts:** 3
- ✅ **Validation Rules:** 19
- 👁️ **List Views:** 18
- 🔐 **Sharing Rules:** 2
- ⚡ **Triggers:** 3
- 🔄 **Workflows:** 8
- 📧 **Email Templates:** 5