# Record Type Label

Column 1: API Name
Column 2: Description
Column 3: Default?
Column 4: Active
Column 5: Profiles Visible